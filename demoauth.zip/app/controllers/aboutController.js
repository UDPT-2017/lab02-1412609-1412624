var aboutController = {
    index: function (req, res) {
        res.render('about');
    }
}

module.exports = aboutController;

