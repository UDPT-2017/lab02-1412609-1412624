var homeController = {
    index: function (req, res) {
        res.render('index');
    }
};
module.exports = homeController;

